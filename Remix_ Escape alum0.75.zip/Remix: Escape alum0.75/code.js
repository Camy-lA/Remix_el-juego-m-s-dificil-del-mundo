var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["d583a7b2-f964-4c0d-9ac2-108ff5a8e76c"],"propsByKey":{"d583a7b2-f964-4c0d-9ac2-108ff5a8e76c":{"name":"golfball_1","sourceUrl":"assets/api/v1/animation-library/gamelab/HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY/category_sports/golfball.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY/category_sports/golfball.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

paddle=createSprite(200,390,100,20)
ball=createSprite(200,200,20,20)
paddle.shapeColor="whithe"
ball.shapeColor="whithe"

var bricks= createGroup();

var score = createGroup();

var gameState = "inicio";


function createBricks(y,color) {

for ( c = 0; c <6; c++) {
  var brick =createSprite(65+54*c,y,50,25)
brick.shapeColor=color;
 bricks.add(brick)
  }  
}
createBricks(65,"purple");
createBricks(65+29,"blue");
createBricks(65+29+29,"yellow");
createBricks(65+29+29+29,"red"); 

function draw() {
  background("black");
    textSize(20);
text("Puntuacion:" +score, 169, 35);
 
if (gameState== "inicio") {
   text("Preciona ESPACIO Para Comenzar", 40, 180);

   if (keyDown("space")) {
   ball.velocityX=5;
   ball.velocityY=-5
  gameState = "play";
  }
 
 }
  
 if (gameState == "play") {
   paddle.x  = World.mouseX
   if (ball.isTouching(bottomEdge)|| score == 120 ){
    gameState="end"
}
 }
 
 if (gameState== "end") {
 ball.velocityX =0
 ball.velocityY=0
 text("FIN DEL JUEGO", 140, 185);
}
 

  createEdgeSprites();
  ball.bounceOff(paddle);
  ball.bounceOff(topEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(rightEdge);
  ball.bounceOff(bricks,brickHit);
  
  
  
drawSprites();
}
function brickHit(ball,brick) {
brick.destroy();
score=score+10
}





// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
