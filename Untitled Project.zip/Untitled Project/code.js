var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var playerPaddle = createSprite(390, 200,10,100);
playerPaddle.shapeColor="red"
var computerPaddle = createSprite(20, 200,10,100);
computerPaddle.shapeColor="blue"
var ball= createSprite(200, 200,30,30);
ball.shapeColor="yellow"

ball.velocityX=2;
ball.velocityY=5;
function draw() {
  background("white");

if ( ball.isTouching(playerPaddle)||ball.isTouching(computerPaddle));{
playSound("sound:category", false);

}

 pinpongrred();
 
 if (keyDown("up")){
  playerPaddle.y =playerPaddle.y-10;
 }
if (keyDown("DOWN_ARROW")) {
  playerPaddle.y=playerPaddle.y+10;
}
if (keyDown("space")) {
ball.velocityX=5;
ball.velocityY=5;
}


computerPaddle.y=ball.y

  
  
 createEdgeSprites();
ball.bounceOff(topEdge);
ball.bounceOff(bottomEdge);
ball.bounceOff(playerPaddle)
ball.bounceOff(computerPaddle);
    drawSprites();
}
function pinpongrred() {
  for (num = 0;num <=400; num=num+20 ){
   line(200,num, 200,num+10);}
}







// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
